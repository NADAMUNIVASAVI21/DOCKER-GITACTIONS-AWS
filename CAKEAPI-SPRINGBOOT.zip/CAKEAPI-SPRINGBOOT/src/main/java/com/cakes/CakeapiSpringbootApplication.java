package com.cakes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CakeapiSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CakeapiSpringbootApplication.class, args);
	}

}
