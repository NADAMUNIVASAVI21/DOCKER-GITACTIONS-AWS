import CakeManager from "./components/CakeManager"

function App() {
  return (
    <>
      <CakeManager />
    </>
  )
}

export default App
